package com.example.survey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
